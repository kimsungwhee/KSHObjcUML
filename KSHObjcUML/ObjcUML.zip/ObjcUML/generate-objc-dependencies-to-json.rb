#!/bin/bash
ruby -Ilib bin/objc_dependency_tree_generator -f json-var "$@"
