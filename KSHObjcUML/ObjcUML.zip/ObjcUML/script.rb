#!/usr/bin/env ruby
# encoding: UTF-8

require_relative 'objc_dependency_tree_generator'

# resolve options from command line
options = ObjCDependencyTreeGenerator.parse_command_line_options

# creating generator
generator = ObjCDependencyTreeGenerator.new options

puts generator.dependencies_to_s